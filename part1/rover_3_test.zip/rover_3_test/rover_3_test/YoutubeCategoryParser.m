//
//  YoutubeCategoryParser.m
//  rover_3
//
//  Created by Ling-Ya Chao on 10/19/12.
//  Copyright (c) 2012 Rover. All rights reserved.
//

#import "YoutubeCategoryParser.h"
#import "YoutubeVideo.h"

@implementation YoutubeCategoryParser

- (NSArray *) retrieveFromCategory: (Category)category numberOfVideos:(NSUInteger) n
{
    //convert category to strings
    NSArray* categories = [[NSArray alloc] initWithObjects: @"Film", @"Autos", @"Music", @"Animals", @"Sports", @"Travel", @"Games", @"People", @"Comedy", @"Entertainment", @"News", @"Howto", @"Education", @"Tech", @"Nonprofit", nil];
    
    //decide max-results
    NSInteger num_of_video = n;
    if (n>50) {num_of_video = 50;}
    
    //get JSON
    NSURL* url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"https://gdata.youtube.com/feeds/api/standardfeeds/top_rated_%@?v=2&max-results=%d&alt=jsonc", [categories objectAtIndex:category], num_of_video]];
    NSString *fileContent= [NSString stringWithContentsOfURL:url encoding:NSStringEncodingConversionAllowLossy error:nil];
    
    //parse JSON
    SBJsonParser *parser = [[SBJsonParser alloc] init];
    NSDictionary *data = (NSDictionary*) [parser objectWithString:fileContent error:nil];
    NSArray* items = [data valueForKeyPath:@"data.items"];
    
    //date formatter
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-ddHH:mm:ss"];
    
    //create array
    NSArray* result = [[NSArray alloc] init];
    NSInteger count = 0;
    for (id item in items) {
        //define all fields
        NSString* title = [item objectForKey:@"title"];
        NSString* descr = [item objectForKey:@"description"];
        NSString* link = [[item objectForKey:@"player"] objectForKey:@"default"];
        //format string before changing to NSDate
        NSString *formattedString = [[item objectForKey:@"uploaded"] stringByReplacingOccurrencesOfString:@"T" withString:@""];
        formattedString = [formattedString stringByReplacingCharactersInRange:NSMakeRange(18, 5) withString:@""];
        NSDate *date = [df dateFromString: formattedString];
        NSNumber* resultNumber = [[NSNumber alloc] initWithInt:count];
        count++;
        BOOL isMusic = FALSE;
        if (category == Music) {isMusic = TRUE;}
        NSString* thumbnail = [[item objectForKey:@"thumbnail"] objectForKey:@"default"];
        //create video and add to array
        YoutubeVideo *video = [[YoutubeVideo alloc] initWithTitle:title description:descr link:link date:date resultNumber:resultNumber isMusic:isMusic withThumbnail:thumbnail];
        result = [result arrayByAddingObject:video];
        }
    return result;
}

@end
