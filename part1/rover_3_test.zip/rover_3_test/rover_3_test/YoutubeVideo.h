#import <Foundation/Foundation.h>
#import "CoreData/CoreData.h"

@interface YoutubeVideo : NSObject
{
    NSString* title;
    NSString* descr;
    NSString* link;
    NSDate* date;
    NSNumber* resultNumber;
    BOOL isFavorite;
    
}
@property (nonatomic, copy) NSString* title;
@property (nonatomic, copy) NSString* descr;
@property (nonatomic, retain) NSString* link;
@property (nonatomic, retain) NSDate* date;
@property (nonatomic, retain) NSNumber* resultNumber;
@property (nonatomic, assign) BOOL isMusic;
@property (nonatomic, retain) NSString *thumbnail;


-(id)initWithTitle:(NSString*)t description:(NSString*)d link:(NSString*)l date:(NSDate*)dat resultNumber:(NSNumber*)num isMusic:(BOOL)music withThumbnail:(NSString *)tLink;

@end
