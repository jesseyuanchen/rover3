//
//  main.m
//  rover_3_test
//
//  Created by Ling-Ya Chao on 10/19/12.
//  Copyright (c) 2012 Rover. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
