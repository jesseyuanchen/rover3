//
//  AppDelegate.h
//  rover_3_test
//
//  Created by Ling-Ya Chao on 10/19/12.
//  Copyright (c) 2012 Rover. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
