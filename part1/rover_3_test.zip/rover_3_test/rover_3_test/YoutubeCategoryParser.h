//
//  YoutubeCategoryParser.h
//  rover_3
//
//  Created by Ling-Ya Chao on 10/19/12.
//  Copyright (c) 2012 Rover. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SBJson.h"

@interface YoutubeCategoryParser : NSObject

typedef enum{
    Film = 0,
    Autos,
    Music,
    Animals,
    Sports,
    Travel,
    Games,
    People,
    Comedy,
    Entertainment,
    News,
    Howto,
    Education,
    Tech,
    Nonprofit,
}Category;

- (NSArray *) retrieveFromCategory: (Category)category numberOfVideos: (NSUInteger)n;

@end
