#import "YoutubeVideo.h"

@implementation YoutubeVideo
@synthesize link, title, date, descr, resultNumber;
@synthesize isMusic, thumbnail;


-(id)initWithTitle:(NSString*)t description:(NSString*)d link:(NSString*)l date:(NSDate*)dat resultNumber:(NSNumber*)num isMusic:(BOOL)music withThumbnail:(NSString *)tLink{
    self = [super init];
    if (self) {
        self.title = t;
        self.descr = d;
        self.link = l;
        self.date = dat;
        self.resultNumber = num;
        isFavorite = NO;
        self.isMusic = music;
        self.thumbnail = tLink;
    }
    return self;
}

@end
